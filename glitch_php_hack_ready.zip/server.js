const express = require("express");
const { exec } = require("child_process");
const app = express();
const port = 3000;

app.use(express.static("public"));

app.get("*", (req, res) => {
  exec(`php -f public/index.php`, (error, stdout, stderr) => {
    if (error) {
      res.status(500).send("PHP Error: " + stderr);
    } else {
      res.send(stdout);
    }
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
