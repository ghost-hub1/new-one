#!/bin/bash
php-cgi -b 9000 &
node server.js
